<?php
header("Access-Control-Allow-Origin: *");
$servername = "localhost";
 



echo $_POST["input_1"] ; 
?>