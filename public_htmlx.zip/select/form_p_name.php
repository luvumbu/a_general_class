<?php
session_start();
require_once "../class/DatabaseHandler.php";




$input_1=$_POST["input_1"];

$input_2=$_POST["input_2"];

require_once "../DatabaseHandler/form_p_name.php";
?>
