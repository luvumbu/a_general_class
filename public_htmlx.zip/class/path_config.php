<?php 
$config_dbname ="u489596434_nakongo";
$config_password ="v3p9r3e@59A";
?>