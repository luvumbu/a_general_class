<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire avec JavaScript</title>
    <link rel="icon" type="image/x-icon" href="https://t3.ftcdn.net/jpg/01/08/08/58/360_F_108085811_ssVzwb50KvRrpvydbke92qnN0dxWBPXu.jpg">
</head>

<body>

 


