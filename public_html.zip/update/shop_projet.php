<?php
header("Access-Control-Allow-Origin: *");

echo "OOOOOOOK" ; 
 
?>