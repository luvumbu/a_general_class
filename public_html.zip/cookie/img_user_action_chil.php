<?php
session_start() ; 
header("Access-Control-Allow-Origin: *");
 

$_SESSION["img_user_action_chil"] = time() ; 
 



 
?>