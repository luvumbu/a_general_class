<?php
session_start() ; 
header("Access-Control-Allow-Origin: *");
 
 
 
unset($_SESSION["session_switch"]) ; 
 
?>