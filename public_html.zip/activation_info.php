 <?php 

 session_start() ; 



 echo  $_SESSION["session_log"] ; 



 ?>


