<div class="card">
  <h3>Follow Me</h3>
  <p>Some text..</p>
</div>