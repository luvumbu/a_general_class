<?php 
session_start() ; 
session_destroy() 
?>

<script>
    window.history.back();
</script>